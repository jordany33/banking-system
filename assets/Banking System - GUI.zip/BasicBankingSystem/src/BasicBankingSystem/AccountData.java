//package BasicBankingSystem;
//
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.io.ObjectOutputStream;
//import java.util.ArrayList;
//
//public class AccountData {
//	
//	private ArrayList<Customer> accountData;
//	
//	public AccountData() {
//		accountData = new ArrayList<Customer>();
//	}
//	
//	public customerData(fileName) {
//		try {
//			accountData = new ArrayList<Customer>();
//			FileInputStream accountStorage = new FileInputStream(fileName);
//			Scanner listReader = new Scanner(accountStorage);
//			
//			
//		} catch (IOException error) {
//			error.printStackTrace();
//		}
//	}
//}
